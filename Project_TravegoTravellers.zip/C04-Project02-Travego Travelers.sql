# Q.1) 
#  a) Create a schema named Travego and create the tables mentioned above with the mentioned column names.
# Also, declare the relevant datatypes for each feature/column in the dataset.
 
 create database if not exists Travego;
use Travego;

# PASSENGER Table Creation:
create table if not exists Passenger(
Passenger_id int,
Passenger_name varchar(20),
Category varchar(20),
Gender varchar(20),
Boarding_City varchar(20),
Destination_City varchar(20),
Distance int,
Bus_Type varchar(20)
);

# PRICE Table Creation:
create table if not exists Price(
id int,
Bus_type varchar(20),
Distance int,
Price int
);

 # b) Insert the data in the newly created tables.
 insert into Passenger values
(1,'Sejal','AC','F','Bengaluru','Chennai',350,'Sleeper'),
(2,'Anmol','Non-AC','M','Mumbai','Hyderabad',700,'Sitting'),
(3,'Pallavi','AC','F','Panaji','Bengaluru',600,'Sleeper'),
(4,'Khusboo','AC','F','Chennai','Mumbai',1500,'Sleeper'),
(5,'Udit','Non-AC','M','Trivandrum','Panaji',1000,'Sleeper'),
(6,'Ankur','AC','M','Nagpur','Hyderabad',500,'Sitting'),
(7,'Hemant','Non-AC','M','Panaji','Mumbai',700,'Sleeper'),
(8,'Manish','Non-AC','M','Hyderabad','Bengaluru',500,'Sitting'),
(9,'Piyush','AC','M','Pune','Nagpur',700,'Sitting') ;
 
insert into price values
(1,'Sleeper',350,770),
(2,'Sleeper',500,1100),
(3,'Sleeper',600,1320),
(4,'Sleeper',700,1540),
(5,'Sleeper',1000,2200),
(6,'Sleeper',1200,2640),
(7,'Sleeper',1500,2700),
(8,'Sitting',500,620),
(9,'Sitting',600,744),
(10,'Sitting',700,868),
(11,'Sitting',1000,1240),
(12,'Sitting',1200,1488),
(13,'Sitting',1500,1860);

# Q.2)
# a) How many female passengers traveled a minimum distance of 600 KMs?
select count(*) as F_Passengers from Passenger where gender = "F" and distance<=600;

# b) Write a query to display the passenger details whose travel distance is greater than 500 and who are traveling in a sleeper bus. 
 select * from Passenger where distance>500 and Bus_type="sleeper";
 
# c) Select passenger names whose names start with the character 'S'
select * from  Passenger where Passenger_name like "S%";

# d) Calculate the price charged for each passenger, displaying the Passenger name, Boarding City, Destination City, Bus type, and Price in the output.

SELECT P.Passenger_name, P.Boarding_City, P.Destination_City, P.Bus_Type, Pr.Price
FROM Travego.Passenger P
JOIN Travego.Price Pr ON P.Bus_Type = Pr.Bus_Type AND P.Distance = Pr.Distance;

# e) What are the passenger name(s) and the ticket price for those who traveled 1000 KMs Sitting in a bus?
# select Passenger_name, from Passenger where Passenger_name
SELECT P.Passenger_name, Pr.Price
FROM Travego.Passenger P
JOIN Travego.Price Pr ON P.Bus_Type = Pr.Bus_Type AND P.Distance = Pr.Distance
WHERE P.Distance = 1000 AND P.Bus_Type = 'Sitting';
-- No Passenger where travelled in the Sitting bus for a distance of 1000 KMs.

# f) What will be the Sitting and Sleeper bus charge for Pallavi to travel from Bangalore to Panaji?

select * from Passenger where Passenger_name = 'Pallavi';
select bus_type,price from Price where distance = (select distance from Passenger where Passenger_name = 'Pallavi');


# g) Alter the column category with the value "Non-AC" where the Bus_Type is sleeper 
select * from Passenger;
update Passenger set category = 'NON-AC' where bus_type = 'Sleeper';

# h) Delete an entry from the table where the passenger name is Piyush and commit this change in the database
delete from Passenger where passenger_name = 'Piyush';
commit;

# i) Truncate the table passenger and comment on the number of rows in the table (explain if required)
truncate table Passenger;
select * from Passenger;

# j) Delete the table passenger from the database.
drop table Passenger;

